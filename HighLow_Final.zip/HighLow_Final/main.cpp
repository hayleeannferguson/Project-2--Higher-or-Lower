/*
 * File:   main.cpp
 * Author: Haylee Ferguson
 * Created on
 * Purpose: Game of Cards: Higher or Lower V5
*/

//System Libraries 
#include <iostream>
#include <fstream>
#include <ctime>
#include <iomanip>
#include <string>
#include <cstdlib>
#include <cmath>
using namespace std;


int main(int argc, char** argv) {
	// Set Random Number seed

	//Declare Variables
	char x, answer, guess = 0, choice; // Diamonds, Spades, Clubs, and Hearts
	int  bet, cardVal, pCard = 0, suitI; //Card value 1-13, including King, Queen, and Jack **comparing face value
	bool drawCard, vBet;
	string suits[] = { "Spades", "Hearts", "Diamonds", "Clubs" };
	string pSuit, suit, card, name;
	float balance;

	// Initialize Inputs 

		cout<<setw(15)<<right<<"Welcome!"<<endl;
		cout<<"Let's play a card game!"<<endl<<endl;                    //Beginning of game 
		cout<<"************************"<<endl;
		cout<<setw(20)<<right<<"HIGHER OR LOWER!"<<endl;
		cout<<"************************"<<endl<<endl;



		bool readRules = true;
		for (int i = 0; i < 1 && readRules; i++) {
			cout<<"Do you want to read the rules? (y/n) "<<endl;
			cin>>choice;

			if (choice == 'y' || choice == 'Y') {
				ifstream file("Rules.txt"); // Open the "Rules.txt" file for reading

				if (!file) {
					cout << "Failed to open file.\n";
					return 1;
				}

				// Read and output the rules from the file
				string line;
				while (getline(file, line)) {
					cout << line << endl;
				}

				file.close(); // Close the file after reading
				readRules = false; // Set the flag to false to exit the loop
			}
			else if (choice == 'n' || choice == 'N') {
				readRules = false; // false to exits the loop
			}
			else {
				cout << "Invalid choice. Please enter 'y' or 'n'.\n";
			}
		}


		cout<<"\nLet's play!"<<endl<<endl;
		cout<<"What is your name?"<<endl;
		cin>>name;
		cout<<"How much money would you like to start with, "<<name<<"?"<<endl;
		cin>>balance;
		cout<<"Enter 'S' to start!";
		cin>>x;
		if (x == 's' || x == 'S')
			cout<<"\n\nLet's begin!"<<endl<<endl;

		do {
			
			cout<<"Your current balance is $"<<balance<<endl;
			cout<<"How much would you like to bet, "<<name<<"?"<<endl;
			cin>>bet;

			if (bet > balance) {
				cout<<"I'm sorry "<<name<<" you don't have enough to place that bet."<<endl;
				cout<<"Please place a new bet."<<endl;
				continue;
			}

			srand(time(0));          //random card and suit 
			suitI = rand() % 4;
			suit = suits[suitI];
			cardVal = rand() % 13 + 2;


			if (cardVal >= 2 && cardVal <= 10) {
				card = to_string(cardVal);
			}
			else {
				switch (cardVal) {
				case 11:
					card = "Jack";                  //Cards and their values
					break;
				case 12:
					card = "Queen";
					break;
				case 13:
					card = "King";
					break;
				case 14:
					card = "Ace";
					break;
				}
			}
			
			//cout << "Your current balance is $" << balance << endl;
			//cout << "How much would you like to bet, " << name << "?" << endl;
			//cin >> bet;

			cout<<"You drew the "<<card<<" of "<<suit<<"."<<endl;
			cout<<"Will the next card be higher (H) or lower (L)?"<<endl;
			cin>>guess;
			cout<<endl;

			srand(time(0));          //random card and suit 
			suitI = rand() % 4;
			suit = suits[suitI];
			pCard = rand() % 13 + 2;


			if (pCard >= 2 && pCard <= 10) {
				card = to_string(pCard);
			}
			else {
				switch (pCard) {
				case 11:
					card = "Jack";                  //Cards and their values
					break;
				case 12:
					card = "Queen";
					break;
				case 13:
					card = "King";
					break;
				case 14:
					card = "Ace";
					break;
				}
			}

			cout<<"The next card is the "<<card<<" of "<<suit<<"."<<endl<<endl;

			if ((guess == 'H' || guess == 'h' && cardVal < pCard) ||
				(guess == 'L' || guess == 'l' && cardVal > pCard)) {
				cout << "Congratulations, "<<name<<"! You guessed correctly!"<<endl<<endl;
				balance += bet;
				cout<<"Would you like to continue playing? (y/n)"<<endl;
				cin>>choice;
			}
			else {
				cout<<"Sorry, "<<name<<", you guessed incorrectly."<<endl<<endl;
				balance -= bet;                                                     //Lose bet amount from balance if guessed incorrectly 
				cout<<"Would you like to continue playing? (y/n)"<<endl;
				cin>>choice;
			}

			if (balance <= 0)
			{
				cout<<"Sorry, "<<name<<" You've run out of funds! Game over! Thanks for playing :)"<<endl;
			}
			
		} while (balance > 0 && choice == 'Y' || choice == 'y');
		



	ofstream outputFile("PlayerData.txt");                                  //Open a new file for writing

	if (!outputFile) {
		cout<<"Failed to create file.\n";
		return 1;
	}

	// Write player's name and money to the file
	outputFile<<"Player: "<<name<<endl;
	outputFile<<"Money: $"<<balance<<endl;

	outputFile.close(); // Close the file after writing
	cout<<"\n\n*******************************************"<<endl;
	cout<<"You finished with $"<<balance<< ", "<<name<<"."<<endl;
	cout<<"Thank you for playing!"<<endl;
	cout<<"*******************************************"<<endl;
	return 0;
}



