/*
 * File:   main.cpp
 * Author: Haylee Ferguson
 * Created on 
 * Purpose: Game of Cards: Higher or Lower V1
 */

//System Libraries 
#include <iostream>
#include <fstream>
#include <ctime>
#include <iomanip>
#include <string>
#include <cstdlib>
#include <cmath>
using namespace std;
//User Libraries

//Global Constants: Math/Physics/Chemistry/Conversions ONLY

//Function Prototypes 

//Execution Begins Here

int main(int argc, char** argv) {
    // Set Random Number seed
    
    //Declare Variables
    char x, name, answer, guess, choice; // Diamonds, Spades, Clubs, and Hearts
    int balance, bet, cardVal, pCard, suitI; //Card value 1-13, including King, Queen, and Jack **comparing face value
    bool drawCard, vBet;
	string suits[] = {"Spades", "Hearts", "Diamonds", "Clubs"};
	string pSuit, suit, card;
	
    // Initialize Inputs 
	do{ 
	cout<<"Welcome, player!"<<endl;
	cout<<"Select an option from the menu!"<<endl;
	cout<<"1. Begin the game"<<endl;
	cout<<"2. Rules of the game"<<endl;
	cin>>choice; 
	
	switch(choice) {
		case 1:{
			cout<<"Let's play a card game"<<endl;
			cout<<"Higher, or Lower!"<<endl;
			cout<<"Welcome player!"<<endl;
			cout<<"What is your name?"<<endl;
			cin>>name;
			cout<<"How much money would you like to start with, "<<name<<"?"<<endl;
			cin>>balance;
			cout<<"Enter 'S' to begin!"<<endl;
			cin>>x;
			if (x == 's'|| x == 'S')
			cout<<"Let's begin!"<<endl;
		
		do{ 
		vBet = false; //placing a bet
		cout<<"Your current balance is "<<balance<<endl;
		cout<<"How much would you like to bet, "<<name<<"?"<<endl;
		cin>>bet; 
		
		if (bet > balance) {
			cout<<"I'm sorry "<<name<<" you don't have enough to place that bet."<<endl;
			cout<<"Would you like to place a new bet? 'Y' for yes and 'N' for no."<<endl;
			cin>>answer; 
			if (answer == 'Y' || answer == 'y'){
				vBet = false;
			}
			else if (answer == 'N' || answer == 'n'){
				vBet = true;
				bet = 0;
			}
		}
		else { 
			vBet = true;
		}
		}while (!vBet);
		
		drawCard = true; 
		while (drawCard){
			srand(time(0));          //random card and suit 
			suitI = rand() % 4;
			suit = suits[suitI];
			cardVal = rand() % 13 + 2; 
			
			
			if (cardVal >= 2 && cardVal <= 10) {
				card = to_string(cardVal);
			}
			else {
				switch (cardVal) {
					case 11:
						card = "Jack";
						break; 
					case 12: 
						card = "Queen"; 
						break;
					case 13: 
						card = "King";
						break;
					case 14: 
						card = "Ace";
						break; 
				}
			}
			
			cout<<"You drew the "<<card<<" of "<<suit<<"."<<endl;
			cout<<"Will the next card be higher (H) or lower (L)?"<<endl;
			cin>>guess;
			
			if ((guess == 'H' || guess == 'h' && cardVal > pCard) ||
				(guess == 'L' || guess == 'l' && cardVal < pCard)) {
					cout<<"Congartulations, "<<name<<" you guessed correctly!"<<endl;
					balance += bet; 
				}
				else {
					cout<<"Sorry, "<<name<<" you guessed incorrectly."<<endl;
					balance -= bet; 
				}
				
				if (balance <0) {
					cout<<"Sorry, "<<name<<" You've run out of funds! Game over! Thanks for plating :)"<<endl;
			
		break;
			}
		
		case 2:{
			cout<<"Here are the rules of the game!"<<endl;
			cout<<"You will begin by entering your name when prompted."<<endl;
			cout<<"Next, you will be asked to enter the amount of betting money you would like to start the game with."<<endl;
			cout<<"After choosing your starting balance, the game will begin."<<endl;
			cout<<"At the start of each game, you will choose whether or not you would like to place a bet."<<endl;
			cout<<"If your bet amount is more than your current balance, you will either have to choose a new bet amount, or not make one at all."<<endl;
			cout<<"Once you have made you bet selection, you will draw a card."<<endl;
			cout<<"When the card is displayed, you will decide if the next card drawn will be a higher value or lower."<<endl;
			cout<<"In this game, the face of each card determines its value."<<endl; 
			cout<<"Numbered cards will hold the value of the number on the card."<<endl;
			cout<<"The Ace card has a value of one."<<endl;
			cout<<"The Jack card has a value of eleven."<<endl;
			cout<<"The Queen card has a value of twelve."<<endl;
			cout<<"The king card has a value of thirteen."<<endl;
			cout<<"Upon guessing correctly, the bet value you placed will return to your balance, and you will be asked if you would like to play again."<<endl;
			cout<<"If you guess incorrectly, the bet value you placed will be deducted from your balance, and you can choose if you would like to play again or exit the game."<<endl;
			cout<<"You can continue to play for as long as you would like, or until you run out of funds to place a bet."<<endl;
			cout<<"You may also continue to play without betting, just be sure to choose not to bet at the beginning of each turn."<<endl;
			cout<<"Those are the rules of the game, player! Have fun!"<<endl;
		break;
		}
		
		default:cout<<endl<<"Exiting menu"<<endl;
		
	}
	
	}while(choice>='1'&&choice<='2'); 

     
    }
    
    
    
    // Map Inputs to Outputs - Process
  
    
    //Display Output
   
    
    //Exit Stage Right 
    
    




    return 0;
}

       