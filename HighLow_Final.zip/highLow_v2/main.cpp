/*
 * File:   main.cpp
 * Author: Haylee Ferguson
 * Created on 
 * Purpose: Game of Cards: Higher or Lower V1
*/

//System Libraries 
#include <iostream>
#include <fstream>
#include <ctime>
#include <iomanip>
#include <string>
#include <cstdlib>
#include <cmath>
using namespace std;
//User Libraries

//Global Constants: Math/Physics/Chemistry/Conversions ONLY

//Function Prototypes 

//Execution Begins Here

int main(int argc, char** argv) {
    // Set Random Number seed
    
    //Declare Variables
    char x, answer, guess, choice; // Diamonds, Spades, Clubs, and Hearts
    int  bet, cardVal, pCard, suitI; //Card value 1-13, including King, Queen, and Jack **comparing face value
    bool drawCard, vBet;
    string suits[] = {"Spades", "Hearts", "Diamonds", "Clubs"};
    string pSuit, suit, card, name;
    float balance; 
	
    // Initialize Inputs 
	do{ 
	cout<<"Welcome, player!"<<endl;
        cout<<"Let's play a card game"<<endl;                    //Beginning of game 
	cout<<"Higher, or Lower!"<<endl;
	
	 
	
	for (;;) {
        cout << "Do you want to read the rules? (y/n) ";
        cin >> choice;

        if (choice == 'y' || choice == 'Y') {
            ifstream file("Rules.txt"); // Open the "Rules.txt" file for reading

            if (!file) {
                cout << "Failed to open file.\n";
                return 1;
            }

            // Read and output the rules from the file
            string line;
            while (getline(file, line)) {
                cout << line << endl;
            }

            file.close(); // Close the file after reading
            break; // Exit the loop after reading and outputting the rules
        } else if (choice == 'n' || choice == 'N') {
            break; // Exit the loop if the player does not want to read the rules
        } else {
            cout << "Invalid choice. Please enter 'y' or 'n'.\n";
        }
    }
			
			cout<<"Welcome player!"<<endl;
			cout<<"What is your name?"<<endl;
			cin>>name;
			cout<<"How much money would you like to start with, "<<name<<"?"<<endl;
			cin>>balance;
			cout<<"Enter 'S' to begin!"<<endl;
			cin>>x;
			if (x == 's'|| x == 'S')
			cout<<"Let's begin!"<<endl;
		
		do{ 
		vBet = false; //placing a bet
		cout<<"Your current balance is "<<balance<<endl;
		cout<<"How much would you like to bet, "<<name<<"?"<<endl;
		cin>>bet; 
		
		if (bet > balance) {
			cout<<"I'm sorry "<<name<<" you don't have enough to place that bet."<<endl;
			cout<<"Would you like to place a new bet? 'Y' for yes and 'N' for no."<<endl;
			cin>>answer; 
			if (answer == 'Y' || answer == 'y'){
				vBet = false;
			}
			else if (answer == 'N' || answer == 'n'){
				vBet = true;
				bet = 0;
			}
		}
		else { 
			vBet = true;
		}
		}while (!vBet);
		
		drawCard = true; 
		while (drawCard && (!(guess == 'E' || guess == 'e'))){
			srand(time(0));          //random card and suit 
			suitI = rand() % 4;
			suit = suits[suitI];
			cardVal = rand() % 13 + 2; 
			
			
			if (cardVal >= 2 && cardVal <= 10) {
				card = to_string(cardVal);
			}
			else {
				switch (cardVal) {
					case 11:
						card = "Jack";                  //Cards and their values
						break; 
					case 12: 
						card = "Queen"; 
						break;
					case 13: 
						card = "King";
						break;
					case 14: 
						card = "Ace";
						break; 
				}
			}
			
			cout<<"You drew the "<<card<<" of "<<suit<<"."<<endl;
			cout<<"Will the next card be higher (H) or lower (L)?"<<endl;
                        cout<<"If you would like to exit the game, enter (E)"<<endl;
			cin>>guess;
			 
                        
			if ((guess == 'H' || guess == 'h' && cardVal > pCard) ||
				(guess == 'L' || guess == 'l' && cardVal < pCard)) {
					cout<<"Congratulations, "<<name<<" you guessed correctly!"<<endl;
					balance += bet; 
				}
				else {
                                                                          
					cout<<"Sorry, "<<name<<" you guessed incorrectly."<<endl;
					balance -= bet;                                                     //Lose bet amount from balance if guessed incorrectly 
                                        
				}
				
				if (balance <0) {
					cout<<"Sorry, "<<name<<" You've run out of funds! Game over! Thanks for playing :)"<<endl;
                                    }
                        if ( guess == 'E' || guess == 'e') {
                            ofstream outputFile("PlayerData.txt");                                  //Open a new file for writing

                    if (!outputFile) {
                    cout<<"Failed to create file.\n";
                    return 1;
    }

                    // Write player's name and money to the file
                    outputFile<<"Player: "<<name<<endl;
                    outputFile<<"Money: $"<<balance<<endl;

                    outputFile.close(); // Close the file after writing

                        }
                
                }    
		
			
		
		
		
		
		
		
	

     
    
        
                }while(balance > 0 || guess!='E' || guess!='e'); 
                    
    return 0;
}
    
    
    
